import React, { useState } from "react";

const JokeGenerator = () => {
  const [joke, setJoke] = useState(null);
  const [loading, setLoading] = useState(false);

  const fetchJoke = async () => {
    setLoading(true);
    try {
      const response = await fetch("https://official-joke-api.appspot.com/random_joke");
      const data = await response.json();
      setJoke(data);
    } catch (error) {
      console.error("Error fetching joke:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-100 to-yellow-300 flex items-center justify-center p-6">
      <div className="bg-white rounded-xl shadow-lg p-8 max-w-lg text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Random Joke Generator</h1>
        <p className="text-gray-600 mb-6">
          Click the button below to generate a random joke and lighten up your day!
        </p>
        <button
          onClick={fetchJoke}
          className="px-6 py-3 bg-blue-500 text-white font-medium rounded-lg hover:bg-blue-600 transition duration-300"
          disabled={loading}
        >
          {loading ? "Fetching Joke..." : "Generate Joke"}
        </button>
        {joke && (
          <div className="mt-6">
            <h2 className="text-xl font-semibold text-gray-700">{joke.setup}</h2>
            <p className="text-lg text-gray-600 mt-2">{joke.punchline}</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default JokeGenerator;